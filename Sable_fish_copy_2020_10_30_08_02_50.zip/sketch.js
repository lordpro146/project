var bananaImage;
var obstacleImage;
var obstaclegroup;
var score=0;
var bg;
var foodgroup;
var monkey

function preload() {
 bg=loadImage("jungle.jpg")

monkey =loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("stone.png");
  
 
  
}

function setup() {
  createCanvas(400, 400);
  monkey = createSprite (50,160,20,50);
  monkey.addAnimation("running", player_running);
  monkey.scale = 0.5;
  bg = createSprite(300,180,600,10);
  bg.x = bg.width/2;
  bananaImage = addImage(bananaImage);
  inground = createSprite(300,190,600,5);
   inground.x = inground.width/2;
  inground.visible = false;
  obstacleGroup = new Group();
  foodGroup = new Group();
  
  score = 0;
}

function draw() {
  background("bg");
  
  if (foodGroup.istouching(monkey)){
    score = score+2;
  }
  
  switch(score){
    case 10 :monkey.scale=0.12
    break;
    case 20 :monkey.scale=0.14
    break;
    case 30 :monkey.scale=0.16
    break;
    case 40 :monkey.scale=0.18
    break;
    default: break;
  }
  
  if (obstacleGroup.istouching(monkey)){
    monkey.scale=0.2
  }
  
 drawSprites();
  stroke("white");
  textsize(20);
  fill("white")
  text("score:"+ score,350,50);
}